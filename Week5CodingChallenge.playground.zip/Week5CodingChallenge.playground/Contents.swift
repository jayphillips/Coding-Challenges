import UIKit

func getSum(for string: String) -> Int? {
    var sum = 0
    let value = string
    let numbers = value.filter({$0.isNumber})
    for number in numbers {
        guard let number = number.wholeNumberValue else { return 0 }
        sum += number
    }
    return sum
}

getSum(for: "GH2U87A")
getSum(for: "U54JSD")
getSum(for: "JAYPHILLIPS")
