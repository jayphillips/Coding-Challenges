import UIKit

func check(_ wordToCheck: String) -> Bool {
    
    if wordToCheck.contains("cei") || wordToCheck.contains("ie") && !wordToCheck.contains("cie") {
        return true
    } else if wordToCheck.contains("cie") || wordToCheck.contains("ei") {
        return false
    }
    return true
}

check("a")
check("zombie")
check("transceiver")
check("veil")
check("icier")
