import UIKit

//Write a function that takes an array of strings and prints them, one per line, in a rectangular frame. For example the list ["This", "is", "a", "frame", "print"] gets printed as:
//
//**********
//* This        *
//* is             *
//* a             *
//* frame     *
//* print       *
//**********

var sentenceArray = ["This", "is", "a", "frame", "print"]

func printInFrame(message: [String]) {
    print("**********")
    for index in message {
        let word = index.padding(toLength: 8, withPad: " ", startingAt: 0)
        print("*\(word)*")
    }
    print("**********")
}

printInFrame(message: sentenceArray)
